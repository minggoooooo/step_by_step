function redirectToJSP() {
  window.location.href = "tabledetail.jsp";
}