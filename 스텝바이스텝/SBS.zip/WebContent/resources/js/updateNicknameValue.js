function updateNicknameValue() {
	var id = document.getElementById("id").value;
	document.getElementById("nickname").value = id;
}

