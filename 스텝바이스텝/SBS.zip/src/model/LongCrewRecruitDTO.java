package model;

public class LongCrewRecruitDTO {

	private String crewName, content, created, adminId, dueDate;
	private int memberNum, totalCount;
	
	
	public String getCrewName() {
		return crewName;
	}
	public String getContent() {
		return content;
	}
	public String getCreated() {
		return created;
	}
	public String getAdminId() {
		return adminId;
	}
	public String getDueDate() {
		return dueDate;
	}
	public int getMemberNum() {
		return memberNum;
	}
	public int getTotalCount() {
		return totalCount;
	}
	public void setCrewName(String crewName) {
		this.crewName = crewName;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	public void setMemberNum(int memberNum) {
		this.memberNum = memberNum;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	
	
	
	
}
